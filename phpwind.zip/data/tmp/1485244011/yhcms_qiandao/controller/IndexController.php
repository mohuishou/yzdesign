<?php
defined('WEKIT_VERSION') || exit('Forbidden');
/**
 * 
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */
class IndexController extends PwBaseController {
	
	public $page = 1;
	public $perpage = 20;
 
     private function _getYhqdaoLevelDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.YhqdaoLevel');
    }
    private function _getYhqdaoDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.Yhqdao');
    }
     
     private function _getYhqdaoLogDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.YhqdaoLog');
    }
    
	private function _getyhcmsDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.yhcms');
    }
    public function run() {
	$this->index();
	//分页处理
		$page = intval($this->getInput('page'));
		$this->page = $page < 1 ? 1 : $page;
		list($offset, $limit) = Pw::page2limit($this->page, $this->perpage);
		$total = $this->_getYhqdaoLogDs()->count('total');
 		$list = $total ? $this->_getYhqdaoLogDs()->getList($limit, $offset ,'total') : array();
		$this->setOutput($total, 'total');
		$this->setOutput($list, 'list');
		$this->setOutput($this->page, 'page');
		$this->setOutput($this->perpage, 'perpage');
    }
	//更新签到会员信息
    public function get_cache(){
	$getUserLog=$this->_getYhqdaoLogDs()->getUserLog();
	$writemsg .="class Yhqdao_User_config{\r\n";
	$writemsg .="public function get_UserClass(){\r\n";
	$writemsg .=$getUserLog;
	$writemsg.="}\r\n";
	$writemsg.="}";
	$this->_getyhcmsDs()->writeover("src/extensions/yhcms_qiandao/service/Yhqdao_User_config.php","<?php\r\n".$writemsg."\r\n?>");
	}
    public function doSaveAction() {
	  //签到配置
	    $service = Wekit::load('config.PwConfig');
 		$config = $service->getValues('Yhqdao');
		$total_Yhqdao = $this->_getYhqdaoLogDs()->count_Yhqdao($this->loginUser->uid);//统计的array
		$user=$this->_getYhqdaoLogDs()->getUser($this->loginUser->uid);//获取当前会员签到记录表信息
        $savemoney = $this->getInput('money','post');//获取表单信息
        $savemoney = intval($savemoney);
        $qddiary = $this->getInput('qddiary','post');
		$qdmode = $this->getInput('qdmode','post');
		$qdxq = $this->getInput('qdxq','post');
        if (!$this->loginUser->uid || $this->loginUser->uid <= 0) {
            $this->showError('请先登录，再签到！');
        }
		if($this->_getYhqdaoDs()->get_times(Pw::getTdtime(),Pw::getTime(),$config[time_sta],$config[time_end])=='1'){	
		$this->showError('对比起，不是签到时间请不要签到！');
		}
		if($total_Yhqdao['sum_user_td']>=$config[sum]){
		$this->showError('今日签到次数已满，请明天签到。');
		}
		if((Pw::getTime()-$user[times])<($config[time_two]*3600)){
		 $this->showError('对不起，下次签到时间未到，请等待！');
		}
		if(($config[sum]-$total_Yhqdao['sum_user_td'])=='1'){
		$savemoney=$savemoney+$config[sum_moeny];
		}
		if (!is_numeric($qdxq) || $qdxq=='') {
            $this->showError('签到心情未选择，请重新签到。');
        }
		if($qdmode=='1'||$qdmode=='2'){
		if (!is_numeric($qdmode) || $qddiary=='') {
            $this->showError('今天我想说不能为空，请重新签到。');
        }
		}else{
		$qddiary='这人很懒，什么都没留下。';
		}
 		//积分配置
		Wind::import('SRV:credit.bo.PwCreditBo');
        $creditBo = PwCreditBo::getInstance();
			$this->_getYhqdaoLogDs()->addLog($qddiary, $savemoney, $this->loginUser->uid, $this->loginUser->username, $this->loginUser->ip, Pw::getTime(),$qdxq);
			$this->get_cache();
			$creditBo->set($this->loginUser->uid,$config[credit],+$savemoney);
            $this->showMessage("签到成功");
        
    }
	
	private function get_userinfo(){
	$credit=array(
	'1' => $this->loginUser->info['credit1'],
	'2' => $this->loginUser->info['credit2'],
	'3' => $this->loginUser->info['credit3'],
	);
	return $credit;
	}
	//今日签到
	public function todayAction(){
	$this->index();
	//分页处理
		$page = intval($this->getInput('page'));
		$this->page = $page < 1 ? 1 : $page;
		list($offset, $limit) = Pw::page2limit($this->page, $this->perpage);
		$total = $this->_getYhqdaoLogDs()->count('tday');
		$today_list = $total ? $this->_getYhqdaoLogDs()->getList($limit, $offset ,'today') : array();
		$this->setOutput($total, 'total');
		$this->setOutput($today_list, 'today_list');
		$this->setOutput($this->page, 'page');
		$this->setOutput($this->perpage, 'perpage');
	$this->setTemplate('today_run');
	}
	//昨日签到
	public function yesterdayAction(){
	$this->index();
	//分页处理
		$page = intval($this->getInput('page'));
		$this->page = $page < 1 ? 1 : $page;
		list($offset, $limit) = Pw::page2limit($this->page, $this->perpage);
		$total = $this->_getYhqdaoLogDs()->count('yesterday');
		$today_list = $total ? $this->_getYhqdaoLogDs()->getList($limit, $offset ,'yesterday') : array();
		$this->setOutput($total, 'total');
		$this->setOutput($today_list, 'today_list');
		$this->setOutput($this->page, 'page');
		$this->setOutput($this->perpage, 'perpage');
	$this->setTemplate('yesterday_run');
	}//天数排行
	public function sumAction(){
	$this->index();
	//分页处理
		$page = intval($this->getInput('page'));
		$this->page = $page < 1 ? 1 : $page;
		list($offset, $limit) = Pw::page2limit($this->page, $this->perpage);
		$total = $this->_getYhqdaoLogDs()->count('sum');
		$today_list = $total ? $this->_getYhqdaoLogDs()->getList($limit, $offset ,'sum') : array();
		$this->setOutput($total, 'total');
		$this->setOutput($today_list, 'today_list');
		$this->setOutput($this->page, 'page');
		$this->setOutput($this->perpage, 'perpage');
	$this->setTemplate('sum_run');
	}//本月排行
	public function sum_monthAction(){
	$this->index();
	//分页处理
		$page = intval($this->getInput('page'));
		$this->page = $page < 1 ? 1 : $page;
		list($offset, $limit) = Pw::page2limit($this->page, $this->perpage);
		$total = $this->_getYhqdaoLogDs()->count('sum');
		$today_list = $total ? $this->_getYhqdaoLogDs()->getList($limit, $offset ,'sum_month') : array();
		$this->setOutput($total, 'total');
		$this->setOutput($today_list, 'today_list');
		$this->setOutput($this->page, 'page');
		$this->setOutput($this->perpage, 'perpage');
	$this->setTemplate('sum_month_run');
	}
	//公共部分
	private function index(){
		//签到配置
 		$service = Wekit::load('config.PwConfig');
 		$config = $service->getValues('Yhqdao');
        Wind::import('SRV:credit.bo.PwCreditBo');
        $creditBo = PwCreditBo::getInstance();
		$usercred=$this->get_userinfo();//当前用户金钱信息
		if(!$config['isopen']){
 			$this->showError('签到中心关闭了');
 		}
		$UserClass= $this->_getUserClassDs()->get_UserClass();//读取签到全部会员用户信息--缓存
		$LevelClass= $this->_getLevelClassDs()->get_LevelClass();//读取签到全等级信息----缓存
		$Leveldb=$this->_getYhqdaoLevelDs()->getList();
        $lrbdb=$this->_getYhqdaoDs()->get_lei('lrbdb');
		$getXin=$this->_getYhqdaoDs()->getXinSum();
		$user=$this->_getYhqdaoLogDs()->getUser($this->loginUser->uid);
		$yh_uid=$this->loginUser->uid;
		$yh_username=$this->loginUser->username;
		$total_Yhqdao = $this->_getYhqdaoLogDs()->count_Yhqdao($this->loginUser->uid);//统计的array
        $images_url="src/extensions/yhcms_qiandao/res/images";
		$this->setOutput($images_url, 'images_url');
		$this->setOutput($lrbdb, 'lrbdb');
		$this->setOutput($getXin, 'getXin');
		$this->setOutput($user, 'user');
		$this->setOutput($yh_uid, 'yh_uid');
		$this->setOutput($yh_username, 'yh_username');
		$this->setOutput($config, 'config');
		$this->setOutput($creditBo, 'creditBo');
		$this->setOutput($usercred, 'usercred');
		$this->setOutput($Leveldb, 'Leveldb');
		$this->setOutput($UserClass, 'UserClass');
		$this->setOutput($LevelClass, 'LevelClass');
		$this->setOutput($total_Yhqdao, 'total_Yhqdao');
	}
	private function _getUserClassDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.Yhqdao_User_config');
    }
	private function _getLevelClassDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.Yhqdao_Level_config');
    }
}