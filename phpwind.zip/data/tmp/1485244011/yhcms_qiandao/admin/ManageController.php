<?php
Wind::import('APPS:admin.library.AdminBaseController');
/**
 * 后台访问入口
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */

class ManageController extends AdminBaseController {
	public $page = 1;
	public $perpage = 20;

    public function run() {
 		$service = Wekit::load('config.PwConfig');
 		$config = $service->getValues('Yhqdao');
        Wind::import('SRV:credit.bo.PwCreditBo');
        $creditBo = PwCreditBo::getInstance();
        $this->setOutput($creditBo, 'creditBo');
		$this->setOutput($config, 'config');
    }
    
	public function cacheAction(){
	$act = $this->getInput('act');
	$n = $this->getInput('n');
	if($act=='sc'){
	$this->get_cache($n);
	$this->showMessage('更新缓存成功');
	}else if($act=='hy'){
	 if($n=='level'){
	 $LevelClass= $this->_getLevelClassDs()->get_LevelClass();//读取签到全等级信息----缓存
	 $this->_getYhqdaoLevelDs()->to_Level($LevelClass);
	 $this->showMessage('还原缓存成功');
	 }else if($n=='user'){
	 $UserClass= $this->_getUserClassDs()->get_UserClass();//读取签到全等级信息----缓存
	 $this->_getYhqdaoLogDs()->to_User($UserClass);
	 $this->showMessage('还原缓存成功');
	 }else if($n=='log'){
	 $LogClass= $this->_getLogClassDs()->get_LogClass();//读取签到全等级信息----缓存
	 $this->_getYhqdaoLogDs()->to_Log($LogClass);
	 $this->showMessage('还原缓存成功');
	 }
	
	}
	$this->setTemplate('cache_run');
	}
	
 	public function doSetAction() {
 		$arr = $this->getInput('config', 'post');
		if($arr[time_sta]>$arr[time_end]){
		$time=(24-$arr[time_sta])+$arr[time_end];
		}else if($arr[time_sta]<$arr[time_end]){
		$time=$arr[time_end]-$arr[time_sta];
		}else if($arr[time_sta]<$arr[time_end]){
		$time='24';
		}
		$time_two=$arr[time_two]*$arr[sum];
		if($time_two>$time){
		 $this->showError('签到时间限制有误，请重新填写！');
		}
 		$config = new PwConfigSet('Yhqdao');
 		foreach($arr as $k => $v){
 			if(!$v)$v=0;
			$config->set($k, $v)->flush();
 		}
		$this->showMessage('设置成功');
 	}
 //签到记录
 	public function logAction() {
	$service = Wekit::load('config.PwConfig');
 		$config = $service->getValues('Yhqdao');
        Wind::import('SRV:credit.bo.PwCreditBo');
        $creditBo = PwCreditBo::getInstance();
        $credit_name = $creditBo->cType[$config[credit]];
		$credit_unit = $creditBo->cUnit[$config[credit]];
		$page = intval($this->getInput('page'));
        $this->page = $page < 1 ? 1 : $page;
        list($offset, $limit) = Pw::page2limit($this->page, $this->perpage);
        $total = $this->_getYhqdaoLogDs()->count('total');
        $list = $total ? $this->_getYhqdaoLogDs()->getList($limit, $offset ,'total') : array();
		$this->setOutput($total, 'total');
        $this->setOutput($list, 'list');
		$this->setOutput($this->page, 'page');
		$this->setOutput($this->perpage, 'perpage');
		$this->setTemplate('log_run');
		$this->setOutput($credit_name, 'credit_name');
		$this->setOutput($credit_unit, 'credit_unit');
 	}
	//删除签到记录信息
	public function DelLogAction() {
	$idArr = $this->getInput('idll','post');
	if(!$idArr){
	$this->showError('请选择删除记录');
	}
    $this->_getYhqdaoLogDs()->delLog($idArr);
	$this->showMessage('删除记录成功');
 	}
	//添加等级
	public function AddlevelAction() {
    $hits = intval($this->getInput('hits', 'post'));
	$dj = intval($this->getInput('dj', 'post'));
	$title = $this->getInput('title', 'post');
	if($title==''){
			$this->showError('请填写等级名称');
        }	
	if($dj<1 || $dj==''){
			$this->showError('等级数填写有误');
        }
		if($hits<1 || $hits==''){
			$this->showError('需要次数填写有误');
        }
    $this->_getYhqdaoLevelDs()->addLevel($title,$dj,$hits);
	$this->get_cache('level');
	$this->showMessage('添加等级成功');
 	}
	//更新缓存
	public function get_cache($type){
	if($type=='level'){
	$getLevelList=$this->_getYhqdaoLevelDs()->getLevelList();
	$writemsg .="class Yhqdao_Level_config{\r\n";
	$writemsg .="public function get_LevelClass(){\r\n";
	$writemsg .=$getLevelList;
	$writemsg.="}\r\n";
	$writemsg.="}";
	$this->_getyhcmsDs()->writeover("src/extensions/yhcms_qiandao/service/Yhqdao_Level_config.php","<?php\r\n".$writemsg."\r\n?>");
	}else if($type=='user'){
	$getUserLog=$this->_getYhqdaoLogDs()->getUserLog();
	$writemsg .="class Yhqdao_User_config{\r\n";
	$writemsg .="public function get_UserClass(){\r\n";
	$writemsg .=$getUserLog;
	$writemsg.="}\r\n";
	$writemsg.="}";
	$this->_getyhcmsDs()->writeover("src/extensions/yhcms_qiandao/service/Yhqdao_User_config.php","<?php\r\n".$writemsg."\r\n?>");
	}else if($type=='log'){
	$getLog=$this->_getYhqdaoLogDs()->getListLog();
	$writemsg .="class Yhqdao_Log_config{\r\n";
	$writemsg .="public function get_LogClass(){\r\n";
	$writemsg .=$getLog;
	$writemsg.="}\r\n";
	$writemsg.="}";
	$this->_getyhcmsDs()->writeover("src/extensions/yhcms_qiandao/service/Yhqdao_Log_config.php","<?php\r\n".$writemsg."\r\n?>");
	}
	}
	//删除等级信息
	public function DelLevelAction() {
	$id = intval($this->getInput('id'));
    $total = $this->_getYhqdaoLevelDs()->DelLevel($id);
	$this->get_cache('level');
	$this->showMessage('删除成功');
 	}
	 //修改等级
    public function EditLevelAction() {
        $dall = $this->getInput('dall', 'post');
		$title = $this->getInput('title', 'post');
		$djll = $this->getInput('djll', 'post');
		$hits = $this->getInput('hits', 'post');
 foreach($dall as $k => $v){
     if(is_numeric($v)){
             $sid++;
	     $selid .= ','.$v ;}
 }
 foreach($djll as $k => $v){
     if(is_numeric($v)){
             $sid++;
	     $djllid .= ','.$v ;}
 }
foreach($hits as $k => $v){
     if(is_numeric($v)){
             $sid++;
	     $hitsid .= ','.$v ;}
 }
 foreach($title as $k => $v){
             $sid++;
	     $titleid .= ','.$v ;
 }
$i=1;
$array_id = explode( ",", $selid);
$dj_id = explode( ",", $djllid);
$hits_id = explode( ",", $hitsid);
$title_id = explode( ",", $titleid);
$nums=substr_count($selid,',');
for( ;$i <= $nums; ++$i){
$id = $array_id[$i];$dj = $dj_id[$i];$hits = $hits_id[$i];$title = $title_id[$i];	
$this->_getYhqdaoLevelDs()->EditLevel($title,$dj,$hits,$id);
}
$this->get_cache('level');
$this->showMessage('修改等级成功');	
    }
	//等级信息
	public function levelAction() {
	$page = intval($this->getInput('page'));
        $this->page = $page < 1 ? 1 : $page;
        list($offset, $limit) = Pw::page2limit($this->page, $this->perpage);
        $total = $this->_getYhqdaoLevelDs()->count();
        $dj_list = $total ? $this->_getYhqdaoLevelDs()->getList($limit, $offset) : array();
		$this->setOutput($total, 'total');
        $this->setOutput($dj_list, 'dj_list');
		$this->setOutput($this->page, 'page');
		$this->setOutput($this->perpage, 'perpage');
		$this->setTemplate('level_run');
 	}
	
    private function _getYhqdaoLogDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.YhqdaoLog');
    }
	private function _getYhqdaoLevelDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.YhqdaoLevel');
    }
	
	private function _getyhcmsDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.yhcms');
    }
		private function _getLevelClassDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.Yhqdao_Level_config');
    }
	private function _getUserClassDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.Yhqdao_User_config');
    }
	private function _getLogClassDs() {
        return Wekit::load('SRC:extensions.yhcms_qiandao.service.Yhqdao_Log_config');
    }
}

?>