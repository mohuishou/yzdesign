<?php
class Yhqdao_Log_config{
public function get_LogClass(){
$LogClassDb=array(
);
return $LogClassDb;
}
}
?>