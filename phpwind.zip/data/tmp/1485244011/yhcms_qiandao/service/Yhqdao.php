<?php
defined('WEKIT_VERSION') || exit('Forbidden');

/**
 * 
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */

 class Yhqdao {
 
   function getXinSum(){
   $leidb=$this->get_lei('leidb');
   $sumdb=$this->get_sumdb();
   $getXin=array(
   'namedb'=>$leidb,
   'sumdb'=>$sumdb,
   'sum'=>$this->get_dbsum(),
   );
   return $getXin;
   }
   function get_dbsum(){
   $sum=$this->_getYhqdaoDao()->dbsum();
   return $sum;
   }
   
   function get_sum($id){
   $sum=$this->_getYhqdaoDao()->count($id);
   return $sum;
   }
   
   function get_sumdb(){
   $sumdb=array(
   '1'=>$this->get_sum('1'),
   '2'=>$this->get_sum('2'),
   '3'=>$this->get_sum('3'),
   '4'=>$this->get_sum('4'),
   '5'=>$this->get_sum('5'),
   '6'=>$this->get_sum('6'),
   '7'=>$this->get_sum('7'),
   '8'=>$this->get_sum('8'),
   '9'=>$this->get_sum('9'),
   );
   return $sumdb;
   }
   //签到时间查询---24小时默认
   public function get_times($Tdtime,$times,$times_sta,$times_end){
   if($times_sta>$times_end){//跨夜时间处理
   if($times<($Tdtime+($times_sta*3600)) && $times>($Tdtime+($times_end*3600))){
   return '1';
   }
   }else if($times_sta<$times_end){//正常时间处理
   if($times<($Tdtime+($times_sta*3600)) || $times>($Tdtime+($times_end*3600))){
   return '1';
   }
   }
   }
  //获取心情类别和默认签到内容
	public function get_lei($type){
	$leidb=array(
	'1'=>array(
		'id'=>'1',
		'title'=>'开心',
	),
	'2'=>array(
		'id'=>'2',
		'title'=>'难过',
	),
	'3'=>array(
		'id'=>'3',
		'title'=>'郁闷',
	),
	'4'=>array(
		'id'=>'4',
		'title'=>'无聊',
	),
	'5'=>array(
		'id'=>'5',
		'title'=>'愤怒',
	),
	'6'=>array(
		'id'=>'6',
		'title'=>'流汗',
	),
	'7'=>array(
		'id'=>'7',
		'title'=>'奋斗',
	),
	'8'=>array(
		'id'=>'8',
		'title'=>'慵懒',
	),
	'9'=>array(
		'id'=>'9',
		'title'=>'倒霉',
	),
);
$lrbdb=array(
  '1'=>array(
		'title'=>'达州论坛真好,我来报道了。',
	), 
	'2'=>array(
		'title'=>'今天好累啊.....来签到啦！',
	),
);
	if($type=='lrbdb'){
	return $lrbdb;
	}else{
	return $leidb;
	}
	}
   
       protected function _getYhqdaoDao() {
        return Wekit::loadDao('SRC:extensions.yhcms_qiandao.service.dao.YhqdaoDao');
    }
   
 }