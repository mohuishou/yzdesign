<?php
class Yhqdao_User_config{
public function get_UserClass(){
$UserClassDb=array(
);
return $UserClassDb;
}
}
?>