<?php
defined('WEKIT_VERSION') || exit('Forbidden');

Wind::import('SRC:library.base.PwBaseDao');

/**
 * 
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */

class YhqdaoLogDao extends PwBaseDao {
    protected $_table = 'yh_qdao';
    protected $_pk = 'id';
   // protected $_dataStruct = array('content', 'money', 'uid', 'author', 'ip', 'times','qdxq');
     /**
	 * 统计数量
	 *
	 * @return int
	 */
  public function count($type,$uid='') {
  if($type=='total'){
		$sql = $this->_bindSql('SELECT count(*) FROM %s ', $this->getTable());
	}elseif($type=='user'){
	$sql = $this->_bindSql('SELECT count(*) FROM %s ',  $this->getConnection()->getTablePrefix().'yh_qduser');
	}else if($type=='money'){
	$sql = $this->_bindSql('SELECT sum(money) FROM %s ',  $this->getTable());
	}else if($type=='tday'){
	$sql = $this->_bindSql('SELECT count(*) FROM %s where times>%s ',  $this->getTable(),Pw::getTdtime());
	}else if($type=='yue'){
	$times_yue=pw::time2str(Pw::getTdtime(),'m');
	$sql = $this->_bindSql('SELECT count(*) FROM %s where times_yue=%s ',  $this->getTable(),$times_yue);
	}else if($type=='syue'){
	$times_syue=pw::time2str(Pw::getTdtime(),'m')-1;
	$sql = $this->_bindSql('SELECT count(*) FROM %s where times_yue=%s ',  $this->getTable(),$times_syue);
	}else if($type=='user_td'){
	$sql = $this->_bindSql('SELECT count(*) FROM %s where times>%s and uid=%s ',  $this->getTable(),Pw::getTdtime(),$uid);
	}else if($type=='yesterday'){//昨天
	$times=Pw::getTdtime()-(24*60*60);
	$sql = $this->_bindSql('SELECT count(*) FROM %s where times>%s and times<%s ',  $this->getTable(),$times,Pw::getTdtime());
	}else if($type=='sum'){//天数排行
	$sql = $this->_bindSql('SELECT count(*) FROM %s ',  $this->getConnection()->getTablePrefix().'yh_qduser');
	}
	return $this->getConnection()->createStatement($sql)->getValue();
	} 
	//获取全部签到数据
	public function getList($limit, $offset = 0 ,$type) {
	if($type=='total'){
		$sql = $this->_bindSql('SELECT * FROM %s ORDER BY id DESC %s', $this->getTable(), $this->sqlLimit($limit, $offset));
		}else if($type=='today'){
		$sql = $this->_bindSql('SELECT * FROM %s where times>%s  ORDER BY id DESC %s', $this->getTable(),Pw::getTdtime(), $this->sqlLimit($limit, $offset));
		}else if($type=='yesterday'){
		$times=Pw::getTdtime()-(24*60*60);
		$sql = $this->_bindSql('SELECT * FROM %s where times>%s and times<%s  ORDER BY id DESC %s', $this->getTable(),$times,Pw::getTdtime(), $this->sqlLimit($limit, $offset));
		}else if($type=='sum'){
		$sql = $this->_bindSql('SELECT * FROM %s  ORDER BY hits DESC %s', $this->getConnection()->getTablePrefix().'yh_qduser', $this->sqlLimit($limit, $offset));
		}else if($type=='sum_month'){
		$sql = $this->_bindSql('SELECT * FROM %s  ORDER BY bhits DESC %s', $this->getConnection()->getTablePrefix().'yh_qduser', $this->sqlLimit($limit, $offset));
		}
		return $this->getConnection()->createStatement($sql)->queryAll();
	}
	//获取全部签到会员数据
	public function getUserList($limit='', $offset = 0) {
		$sql = $this->_bindSql('SELECT * FROM %s ORDER BY uid ASC %s', $this->getConnection()->getTablePrefix().'yh_qduser', $this->sqlLimit($limit, $offset));
		return $this->getConnection()->createStatement($sql)->queryAll();
	}
	
	//添加签到记录
    public function addLog($data) {
		if (!($clear = $this->_filterStruct($data))) return false;
		
		$sql = $this->_bindSql('INSERT INTO %s SET %s', $this->getTable(), $this->sqlSingle($clear));
		return $this->getConnection()->execute($sql);
    }
  
   //获取今天签到数量
    public function get_DaySum($uid) {
		$sql = $this->_bindSql('SELECT count(*) FROM %s where uid=$uid ', $this->getTable());
		return $this->getConnection()->createStatement($sql)->getValue();
	} 
	//获取签到用户数量
    public function get_UserSum($uid) {
		$sql = $this->_bindSql('SELECT count(*) FROM %s where uid=%s ', $this->getConnection()->getTablePrefix().'yh_qduser',$uid);
		return $this->getConnection()->createStatement($sql)->getValue();
	} 
	//添加签到用户记录
    public function addUser($data) {
		if (!($clear = $this->_filterStruct($data))) return false;
		$sql = $this->_bindSql('INSERT INTO %s SET %s', $this->getConnection()->getTablePrefix().'yh_qduser', $this->sqlSingle($clear));
		return $this->getConnection()->execute($sql);
    }
	//修改签到用户记录
    public function EditUser($data,$uid) {
		if (!($clear = $this->_filterStruct($data))) return false;
		$sql = $this->_bindSql('UPDATE %s SET %s where uid=%s', $this->getConnection()->getTablePrefix().'yh_qduser', $this->sqlSingle($clear),$uid);
		return $this->getConnection()->execute($sql);
    }
	
	//获取签到用户信息
	public function getUser($uid) {
        $sql = $this->_bindSql('SELECT * FROM %s WHERE uid = %s',  $this->getConnection()->getTablePrefix().'yh_qduser', $uid);
		return $this->getConnection()->createStatement($sql)->getOne();
    }
	//获取签到用户等级信息
	public function getUserDj($dj) {
        $sql = $this->_bindSql('SELECT * FROM %s WHERE dj = %s',  $this->getConnection()->getTablePrefix().'yh_qdlevel', $dj);
		return $this->getConnection()->createStatement($sql)->getOne();
    }
	 public function delLog($idArr) {
		$sql = $this->_bindSql('DELETE FROM %s WHERE id in %s', $this->getTable(), $this->sqlImplode($idArr));
		return $this->getConnection()->execute($sql);
    }
}