<?php
defined('WEKIT_VERSION') || exit('Forbidden');

Wind::import('SRC:library.base.PwBaseDao');

/**
 * 
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */

class YhqdaoDao extends PwBaseDao {
    protected $_table = 'yh_qdao';
    protected $_pk = 'id';
  public function dbsum() {
		$sql = $this->_bindSql('SELECT count(*) FROM %s ', $this->getTable());
		return $this->getConnection()->createStatement($sql)->getValue();
	} 
  public function count($id) {
		$sql = $this->_bindSql('SELECT count(*) FROM %s where qdxq=%s', $this->getTable(),$id);
		return $this->getConnection()->createStatement($sql)->getValue();
	} 
	
}