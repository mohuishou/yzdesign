<?php
defined('WEKIT_VERSION') || exit('Forbidden');

Wind::import('SRC:library.base.PwBaseDao');

/**
 * 
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */

class YhqdaoLevelDao extends PwBaseDao {
    protected $_table = 'yh_qdlevel';
    protected $_pk = 'id';
   //统计
  public function count() {
		$sql = $this->_bindSql('SELECT count(*) FROM %s ', $this->getTable());
		return $this->getConnection()->createStatement($sql)->getValue();
	} 
	//获取全部等级数据
	public function getList($limit, $offset = 0) {
		$sql = $this->_bindSql('SELECT * FROM %s ORDER BY dj DESC %s', $this->getTable(), $this->sqlLimit($limit, $offset));
		return $this->getConnection()->createStatement($sql)->queryAll();
	}
	
	//添加等级记录
    public function addLevel($data) {
		if (!($clear = $this->_filterStruct($data))) return false;
		$sql = $this->_bindSql('INSERT INTO %s SET %s', $this->getTable(), $this->sqlSingle($clear));
		return $this->getConnection()->execute($sql);
    }
  //删除等级
    public function DelLevel($id) {
		$sql = $this->_bindSql('DELETE FROM %s WHERE dj=%s', $this->getTable(),$id);
		return $this->getConnection()->execute($sql);
    }
   //修改等级
    public function EditLevel($data,$id) {
		if (!($clear = $this->_filterStruct($data))) return false;
		$sql = $this->_bindSql('UPDATE %s SET %s where dj=%s', $this->getTable(), $this->sqlSingle($clear),$id);
		return $this->getConnection()->execute($sql);
    }
}