<?php
defined('WEKIT_VERSION') || exit('Forbidden');

/**
 *签到等级 
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */

 class YhqdaoLevel {
  /**
	 * 统计数量
	 *
	 * @return int
	 */
	public function count() {
		return $this->_getYhqdaoLevelDao()->count();
	}
  
    /**
	 * 获得全部记录列表
	 *
	 * @param int $limit
	 * @return int  $offset
	 * @return array
	 */
	public function getList($limit, $offset = 0) {
		$result = $this->_getYhqdaoLevelDao()->getList($limit, $offset);
		return $result;
	}
    //添加等级记录
    public function addLevel($title,$dj,$hits) {
        $fieldData = array('title'=>$title, 'dj'=>$dj, 'hits'=>$hits);
    	$result = $this->_getYhqdaoLevelDao()->addLevel($fieldData);
		return $result;
    }
	 //还原等级记录
    public function to_Level($Leveldb) {
	    if($Leveldb){
		foreach($Leveldb as $key=>$val){
        $fieldData = array('title'=>$val[title], 'dj'=>$val[dj], 'hits'=>$val[hits]);
    	$result = $this->_getYhqdaoLevelDao()->addLevel($fieldData);
		}
		}
		return $result;
    }
	 //修改等级记录
    public function EditLevel($title,$dj,$hits,$id) {
        $fieldData = array('title'=>$title,'dj'=>$dj, 'hits'=>$hits);
    	$result = $this->_getYhqdaoLevelDao()->EditLevel($fieldData,$id);
		return $result;
    }
     /**
	 * 删除等级
	 *
	 * @param int $limit
	 * @return int  $offset
	 * @return array
	 */
	public function DelLevel($id) {
		$result = $this->_getYhqdaoLevelDao()->DelLevel($id);
		return $result;
	}
	   /**
	 * 获得全部等级列表--做缓存
	 *
	 * @param int $limit
	 * @return int  $offset
	 * @return array
	 */
	public function getLevelList($limit='', $offset = 0) {
		$result = $this->_getYhqdaoLevelDao()->getList($limit, $offset);
		$writemsg ="\$LevelClassDb=array(\r\n";
		 $i='-1';
	    foreach($result as $key=>$val){
		$writemsg.="\t'$val[dj]'=>array(\r\n\t";
		 $i++;
		foreach($result[$i] as $key=>$value){
			$writemsg.="\t'$key'=>'$value',\r\n\t";
		}
		$writemsg.="),\r\n";
	}
	$writemsg.=");\r\n";
	$writemsg .="return \$LevelClassDb;\r\n";
	return $writemsg;
	}
    protected function _getYhqdaoLevelDao() {
        return Wekit::loadDao('SRC:extensions.yhcms_qiandao.service.dao.YhqdaoLevelDao');
    }
 }