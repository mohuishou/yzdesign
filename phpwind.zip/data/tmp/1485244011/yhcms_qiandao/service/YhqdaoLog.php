<?php
defined('WEKIT_VERSION') || exit('Forbidden');

/**
 * 签到DS服务
 *
 * @author 杨周 <yzhou91@aliyun-inc.com> QQ:89652519
 * @copyright ©2003-2103 phpwind.com
 * @license http://www.yhcms.com
 * @package wind
 */

 class YhqdaoLog {
  
  /**
	 * 统计数量
	 *
	 * @return int
	 */
	public function count($type) {
		return $this->_getYhqdaoLogDao()->count($type);
	}
	public function count_Yhqdao($uid='') {
	$count=array(
	'sum_user'=>$this->_getYhqdaoLogDao()->count('user'),
	'sum_money'=>$this->_getYhqdaoLogDao()->count('money'),
	'sum_tday'=>$this->_getYhqdaoLogDao()->count('tday'),
	'sum_yue'=>$this->_getYhqdaoLogDao()->count('yue'),
	'sum_syue'=>$this->_getYhqdaoLogDao()->count('syue'),
	'sum_user_td'=>$this->_getYhqdaoLogDao()->count('user_td',$uid),
	);
	return $count;
	}
    /**
	 * 获得签到会员信息
	 *
	 * @param int $limit
	 * @return int  $offset
	 * @return array
	 */
	public function getUser($uid) {
		$user=$this->_getYhqdaoLogDao()->getUser($uid);
		return $user;
	}
    /**
	 * 获得全部记录列表
	 *
	 * @param int $limit
	 * @return int  $offset
	 * @return array
	 */
	public function getList($limit, $offset = 0 ,$type) {
		$result = $this->_getYhqdaoLogDao()->getList($limit, $offset,$type);
		return $result;
	}
    //添加签到记录
    public function addLog($content, $money, $uid, $author, $ip, $times,$qdxq) {
	    $times_yue=pw::time2str($times,'m');
        $fieldData = array('content'=>$content, 'money'=>$money, 'uid'=>$uid, 'author'=>$author, 'ip'=>$ip, 'times'=>$times,'qdxq'=>$qdxq,'times_yue'=>$times_yue);
    	$result = $this->_getYhqdaoLogDao()->addLog($fieldData);
		if($this->_getYhqdaoLogDao()->get_UserSum($uid)){
		$this->EditUser($uid,$money,$content,$times);
		}else{
		$this->addUser($uid,$author,$times,$money,$content);
        }
		return $result;
    }
	 //添加签到记录
    public function addUser($uid,$author,$times,$money,$content) {
        $fieldData = array('uid'=>$uid,'author'=>$author, 'times'=>$times,'hits'=>'1', 'money'=>$money,'day'=>'1', 'shits'=>'0','bhits'=>'1','content'=>$content,'dj'=>'1' );
    	$result = $this->_getYhqdaoLogDao()->addUser($fieldData);
        return $result;
    }
	
	 //修改签到记录
    public function EditUser($uid,$money,$content,$times) {
	$user=$this->_getYhqdaoLogDao()->getUser($uid);
	if($this->get_UserDj('3',$user[dj],$user[hits])=='0'){
	$dj=$user[dj]+1;
	}else{
	$dj=$user[dj];
	}
	$hits=$user[hits]+1;
	$money=$user[money]+$money;
	$bhits=$user[bhits]+1;
        $fieldData = array('hits'=>$hits,'money'=>$money,'bhits'=>$bhits,'times'=>$times,'content'=>$content,'dj'=>$dj);
    	$result = $this->_getYhqdaoLogDao()->EditUser($fieldData,$uid);
        return $result;
    }
	
	public function get_UserDj($i,$dj,$hits){
	if($i=='3'){
	$dj=$dj+1;
	$hitsx=$hits+1;
	$dj = $this->_getYhqdaoLogDao()->getUserDj($dj);
	$hits=$dj[hits]-$hitsx;
	return $hits;
	}
	}
	
 //删除记录
   public function delLog($idArr) {
        $result = $this->_getYhqdaoLogDao()->delLog($idArr);
        return $result;
    }
	 /**
	 * 获得全部签到会员信息--做缓存
	 *
	 * @param int $limit
	 * @return int  $offset
	 * @return array
	 */
	public function getUserLog() {
		$UserList=$this->_getYhqdaoLogDao()->getUserList();
		$writemsg ="\$UserClassDb=array(\r\n";
	    $i='-1';
		foreach($UserList as $key=>$val){
		$writemsg.="\t'$val[uid]'=>array(\r\n\t";
		$i++;
		foreach($UserList[$i] as $key=>$value){
			$writemsg.="\t'$key'=>'$value',\r\n\t";
		}
		$writemsg.="),\r\n";
	}
	$writemsg.=");\r\n";
	$writemsg .="return \$UserClassDb;\r\n";
	return $writemsg;
	}
	 /**
	 * 获得全部签到记录信息--做缓存
	 *
	 * @param int $limit
	 * @return int  $offset
	 * @return array
	 */
	public function getListLog() {
		$List=$this->_getYhqdaoLogDao()->getList($limit, $offset ,'total');
		$writemsg ="\$LogClassDb=array(\r\n";
	    $i='-1';
		foreach($List as $key=>$val){
		$writemsg.="\t'$val[id]'=>array(\r\n\t";
		$i++;
		foreach($List[$i] as $key=>$value){
			$writemsg.="\t'$key'=>'$value',\r\n\t";
		}
		$writemsg.="),\r\n";
	}
	$writemsg.=");\r\n";
	$writemsg .="return \$LogClassDb;\r\n";
	return $writemsg;
	}
	
	 //还原签到记录
    public function to_Log($Logdb) {
	    if($Logdb){
		foreach($Logdb as $key=>$v){
        $fieldData = array('id'=>$v[id],'content'=>$v[content], 'money'=>$v[money], 'uid'=>$v[uid], 'author'=>$v[author], 'ip'=>$v[ip], 'times'=>$v[times],'qdxq'=>$v[qdxq],'times_yue'=>$v[times_yue]);
    	$result = $this->_getYhqdaoLogDao()->addLog($fieldData);
		}
		}
		return $result;
    }
	
	 //还原会员记录
    public function to_User($Userdb) {
	    if($Userdb){
		foreach($Userdb as $key=>$v){
        $fieldData = array('uid'=>$v[uid],'author'=>$v[author], 'times'=>$v[times],'hits'=>$v[hits], 'money'=>$v[money],'day'=>$v[day], 'shits'=>$v[shits],'bhits'=>$v[bhits],'content'=>$v[content],'dj'=>$v[dj] );
    	$result = $this->_getYhqdaoLogDao()->addUser($fieldData);
		}
		}
		return $result;
    }
    protected function _getYhqdaoLogDao() {
        return Wekit::loadDao('SRC:extensions.yhcms_qiandao.service.dao.YhqdaoLogDao');
    }
 }