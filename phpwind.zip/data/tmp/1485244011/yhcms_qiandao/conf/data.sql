﻿DROP TABLE IF EXISTS pw_yh_qduser;
CREATE TABLE  `pw_yh_qduser` (
  `uid` int(10)  NOT NULL COMMENT '用户ID',
  `author` varchar(15) NOT NULL COMMENT '用户名',
  `times` int(10)  NOT NULL  COMMENT '第一次签到时间',
  `hits` int(10)  NOT NULL  COMMENT '总签到次数',
  `money` int(10) NOT NULL  COMMENT '总奖励',
  `day` int(10) NOT NULL  COMMENT '总签到天数',
  `shits` int(10) NOT NULL  COMMENT '总签到次数',
  `bhits` int(10) NOT NULL  COMMENT '总签到次数',
  `content` text NOT NULL  COMMENT '签到内容',
  `dj` int(10) NOT NULL  COMMENT '签到等级',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT '签到会员记录表';
DROP TABLE IF EXISTS pw_yh_qdlevel;
CREATE TABLE  `pw_yh_qdlevel` (
  `hits` int(10)  NOT NULL COMMENT '需要次数',
  `dj` int(10) NOT NULL  COMMENT '等级数',
  `title` varchar(100) NOT NULL  COMMENT '等级名称',
  PRIMARY KEY (`dj`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT '签到等级表';
DROP TABLE IF EXISTS pw_yh_qdao;
CREATE TABLE  `pw_yh_qdao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '动态ID',
  `uid` int(10)  NOT NULL DEFAULT '0' COMMENT '用户ID',
  `author` varchar(15) NOT NULL DEFAULT '' COMMENT '用户名',
  `times` int(10)  NOT NULL DEFAULT '0'  COMMENT '签到时间',
  `times_yue` int(10)  NOT NULL DEFAULT '0'  COMMENT '签到时间月',
  `qdxq` int(10)  NOT NULL DEFAULT '0'  COMMENT '签到心情',
  `money` int(10) NOT NULL DEFAULT '0' COMMENT '签到奖励',
  `ip` varchar(100) NOT NULL DEFAULT ''  COMMENT '签到ip',
  `content` text NOT NULL COMMENT '签到内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT '签到记录表';
