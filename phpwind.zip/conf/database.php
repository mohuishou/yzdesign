<?php
  return array(
	'dsn' => 'mysql:host=localhost;dbname=phpwind;port=3306',
	'user' => 'root',
	'pwd' => '',
	'charset' => 'utf8',
	'tableprefix' => 'pw_',
	'engine' => 'MyISAM',
);
?>