<?php
defined('WEKIT_VERSION') or exit(403);
/**
 * 
 */

return array(
	'web-apps' => array(
		'acloud' => array(
		)
	)
);