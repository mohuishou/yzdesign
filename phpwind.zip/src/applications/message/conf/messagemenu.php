<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'contents_message' => array('私信管理', 'message/manage/*', '', '', 'contents'), 
	'operations_link' => array('消息群发', 'message/manage/send', '', '', 'operations'), 
);