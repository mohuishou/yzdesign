<?php
defined('WEKIT_VERSION') or exit(403);
return array(
	'database' => array('数据', array()),
	'database_backup' => array('数据库', 'backup/backup/*', '', '', 'database'), 
);