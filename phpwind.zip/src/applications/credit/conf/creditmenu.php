<?php
return array(
	'config_credit' => array('积分设置', 'credit/credit/*', '', '', 'config', 'config_verifycode'),
);